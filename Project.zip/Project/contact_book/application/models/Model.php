<?php
class Model extends CI_model{

function insert_form($data)
{

    $this->db->insert('contact_form',$data);

}

function contact_view()
{
    $exe = $this->db->get('contact_form');
    return $exe->result_array();


}

function Edit($id)
{

    $exe = $this->db->get_where('contact_form', array('id'=>$id));
    return $exe->result_array();
}

function Update($data, $id)
{
     

        $this->db->update('contact_form', $data, array('id'=>$id));
}

function delete($id)
{

$this->db->delete('contact_form', array('id'=>$id));

}

}

?>