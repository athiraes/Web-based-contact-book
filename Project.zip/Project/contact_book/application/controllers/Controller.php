<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controller extends CI_Controller {

	public function __construct() {

        parent::__construct();

        $this->load->helper(array('form'));
        
               $this->load->library('form_validation');
               $this->load->model('Model');
        }

	public function index()
	{
           

      $this->load->view('index');


	}
   
    public function insert()
    {
      
  
      $data['name'] = $this->input->post('name');
       
      $data['phone_no'] = $this->input->post('mobile');
       //  print_r($data);

      $this->Model->insert_form($data);

       
      echo "<script>
            alert('Added successfully!!');
            window.location.href='http://localhost/contact_book/index.php/Controller/index';
            </script>";
         
    }

    public function view()
    {
      $exe['val'] = $this->Model->contact_view();
      $this->load->view('list_view1',$exe);
    }

    public function edit($id)
    {
    
      $exe['val'] = $this->Model->Edit($id);
   
    $this->load->view('edit_page', $exe);
      
    }
     
    function update()
     {
      
      $id = $this->input->post('id');
      //echo $id;
      $data['name']= $this->input->post('name');
      
      $data['phone_no']= $this->input->post('mobile');
      //print_r($data);die;
      $this->Model->Update($data, $id);
      redirect(base_url()."index.php/Controller/view/");
      
      }

      function Delete($id)
      {
      $this->Model->delete($id);
      
      redirect(base_url()."index.php/Controller/view/");
      
      }
}




?>