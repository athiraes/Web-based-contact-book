<!DOCTYPE html>
<html lang="en">
<head>
	<title>Product Form</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('fonts/font-awesome-4.7.0/css/font-awesome.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('fonts/Linearicons-Free-v1.0.0/icon-font.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/animate/animate.css')?>">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/css-hamburgers/hamburgers.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/animsition/css/animsition.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/select2/select2.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/daterangepicker/daterangepicker.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/util.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/main.css')?>">

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');background-color: #4CAF50;">
			<div class="wrap-login100 p-l-110 p-r-110 p-t-62 p-b-33">
				<form class="login100-form validate-form flex-sb flex-w" action="<?php echo base_url()."index.php/Admin/Shop_Controller/products_insertion/"?>" method="post">
					<span class="login100-form-title p-b-53">
						Add New Product
					</span>
					
					<div class="p-t-31 p-b-9">
						<span class="txt1">
							Product Name
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "product name is required">
						
						<input type="text" name="prod_name"  class="input100" placeholder="Enter product name"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Unit Price
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Unit price is required">
						
						<input type="number" name="unit_price"  class="input100" placeholder="Enter unit price"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Transport Tax
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Transport tax is required">
						
						<input type="number" name="transport_tax"  class="input100" placeholder="Enter transport tax"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Sales tax
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Sales tax is required">
						
						<input type="number" name="sales_tax"  class="input100" placeholder="Enter sales tax"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Minimum selling price
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Minimum selling price is required">
						
						<input type="number" name="minimum_selling_price"  class="input100" placeholder="Enter minimum selling price"/>
						<span class="focus-input100"></span>
					</div>
					
					
					<!---<div class="wrap-input100 validate-input" data-validate = "Phone Number is required">
					
						<input type="number"  name="mobile" placeholder="Enter your Phone no"  class="input100" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;"/>
						<span class="focus-input100"></span>
					</div> -->

					<div class="container-login100-form-btn m-t-17">
						

						<input type="submit" name="submit" value="Submit"  class="login100-form-btn">
					</div>

					<div class="w-full text-center p-t-55">
						

						<a href="<?php echo base_url('index.php/Admin/Shop_Controller/prod_view/')?>" class="txt2 bo1" style="">
						Click here to view Product lists 
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	<script src="<?php echo base_url('vendor/jquery/jquery-3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/animsition/js/animsition.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/bootstrap/js/popper.js')?>"></script>
	<script src="<?php echo base_url('vendor/bootstrap/js/bootstrap.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/select2/select2.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/daterangepicker/moment.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/daterangepicker/daterangepicker.js')?>"></script>
	<script src="<?php echo base_url('vendor/countdowntime/countdowntime.js')?>"></script>
	<script src="<?php echo base_url('js/main.js')?>"></script>

</body>
</html>