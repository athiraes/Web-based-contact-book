<!DOCTYPE html>
<html lang="en">
<head>
    <style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 500px;
  
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
	<title>Product Form</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('fonts/font-awesome-4.7.0/css/font-awesome.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('fonts/Linearicons-Free-v1.0.0/icon-font.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/animate/animate.css')?>">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/css-hamburgers/hamburgers.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/animsition/css/animsition.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/select2/select2.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/daterangepicker/daterangepicker.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/util.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/main.css')?>">

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');background-color: #4CAF50;">
			<div class="wrap-login100 p-l-110 p-r-110 p-t-62 p-b-33">
				<form class="login100-form validate-form flex-sb flex-w" action="<?php echo base_url()."index.php/Shop_Controller/insert_data"?>" method="post">
					<span class="login100-form-title p-b-53">
						Add sales order of products
					</span>

					
					<div class="p-t-31 p-b-9">
						<span class="txt1">
							Product Name
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "product name is required">
						<select name="prodt_name" class="input100" id="product">
                        <option>Choose</option>
                    <?php
                    foreach($val as $fetch){

                    ?>
                            <option><?php echo $fetch['product_name']?></option>

                    <?php } ?>
                        </select>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Add quantity
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Add quantity is required">
						
						<input type="number" name="add_quantity"  class="input100" id="quantity1" placeholder="Enter Add quantity"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Details of product
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Transport tax is required">
                      
					
                      <?php
                       // foreach($val as $fetch){
                      ?> 
					<h4 style="margin-left:15px;">Product name: </h4>
					<h5 style="margin-left:15px;">unit price: </h5>
					<h5 style="margin-left:15px;">Transport tax: </h5>
					<h5 style="margin-left:15px;">Sales tax: </h5>
					<h5 style="margin-left:15px;">Quantity: </h5>
					<h5 style="margin-left:15px;">Total cost: </h5>
					<h5 style="margin-left:15px;">Total msp: </h5>
                      <!-- <h3><?php echo $fetch['product_name']?></h3>
                      <h4><?php echo $fetch['unit_price']?></h4>
                      <h4><?php echo $fetch['transport_tax']?></h4>
                      <h4><?php echo $fetch['sales_tax']?></h4> -->
                       
                    <?php 
					//} 
					?> 
                     
						<span class="focus-input100"></span>
					</div>

					<div class="container-login100-form-btn m-t-17">
						

						<input type="submit" name="submit" value="Submit"  class="login100-form-btn">
					   </div>
                    
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	<script src="<?php echo base_url('vendor/jquery/jquery-3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/animsition/js/animsition.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/bootstrap/js/popper.js')?>"></script>
	<script src="<?php echo base_url('vendor/bootstrap/js/bootstrap.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/select2/select2.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/daterangepicker/moment.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/daterangepicker/daterangepicker.js')?>"></script>
	<script src="<?php echo base_url('vendor/countdowntime/countdowntime.js')?>"></script>
	<script src="<?php echo base_url('js/main.js')?>"></script>
	<script type="text/javascript">
        $(document).ready(function(){
 
            $('#product').change(function(){ 
                var id=$(this).val();
                $.ajax({
                    url : "<?php echo base_url('Shop_Controller/insert_data');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                         
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            html += '<input type='number' id='quantity1' />';
                        }
 
                    }
                });
                return false;
            }); 
             
        });
    </script>
</body>
</html>