<!DOCTYPE html>
<html lang="en">
<head>
    <style>
.blue  {
  background-color: #008CBA; /* blue */
  border: none;
  color: white;
  padding: 15px 34px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius:20px;
}
.red  {
  background-color: #f44336; /* red */
  border: none;
  color: white;
  padding: 15px 30px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius:20px;
}
.previous {
    background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius:20px;
}
        </style>
	<title>Product list details</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('fonts/font-awesome-4.7.0/css/font-awesome.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('fonts/Linearicons-Free-v1.0.0/icon-font.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/animate/animate.css')?>">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/css-hamburgers/hamburgers.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/animsition/css/animsition.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/select2/select2.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/daterangepicker/daterangepicker.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/util.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/main.css')?>">

</head>
<body> 
	
	<div class="limiter">
		<div class="container-login100" style="background-color: #008CBA;">
			<div class="wrap-login100 p-l-110 p-r-110 p-t-62 p-b-33">
				<form class="login100-form validate-form flex-sb flex-w" action="<?php echo base_url()."index.php/Admin/Shop_Controller/products_insertion/"?>" method="post" style="background-image: url('images/bg-01.jpg');">
					<span class="login100-form-title p-b-53">
						
					</span>

				    <table class="styled-table" style="">
    
    <thead>
      <tr>
          <th style="color:Black;">Sl no</th> 

          <th style="color:Black;">Product Name</th> 
    
          <th style="color:Black;">Unit Price</th>

          <th style="color:Black;">Transport Tax</th>

          <th style="color:Black;">Sales Tax</th>

          <th style="color:Black;">Minimum selling price</th>

      </tr>
                      
     </thead>                 
     <?php 
if(empty($val)){
    echo "<tr><td style='color:red'><h3>There are currently no data here</h3></td></tr>";
}else{
foreach($val as $fetch)
{
?>


<tr><td style="color:green"><?php echo $fetch['id']?></td>
    <td style="color:green"><?php echo $fetch['product_name']?></td>
    <td style="color:green"><?php echo $fetch['unit_price']?></td>
    <td style="color:green"><?php echo $fetch['transport_tax']?></td>
    <td style="color:green"><?php echo $fetch['sales_tax']?></td>
    <td style="color:green"><?php echo $fetch['msp']?></td>

 <td><a href="<?php echo base_url()."index.php/Admin/Shop_Controller/edit/".$fetch['id']?>" class="blue" >Edit</a></td>
 <td><a href="<?php echo base_url()."index.php/Admin/Shop_Controller/delete/".$fetch['id']?>" class="red " onclick="return checkdelete()" >Delete</a></td></tr>


<?php
 }
    }
?>  

 <script type="text/javascript">

   function checkdelete()
   {

     return confirm('Are you sure you want to delete this data');
     

   }


</script>              
              
         
            
</table>   
      
<button class="previous">
  
  <a href="http://localhost/Shop/Codeigniter/index.php/Admin/Shop_Controller/index" style="font-color:white;">  &laquo; Back</a></button>
					
					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	<script src="<?php echo base_url('vendor/jquery/jquery-3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/animsition/js/animsition.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/bootstrap/js/popper.js')?>"></script>
	<script src="<?php echo base_url('vendor/bootstrap/js/bootstrap.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/select2/select2.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/daterangepicker/moment.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/daterangepicker/daterangepicker.js')?>"></script>
	<script src="<?php echo base_url('vendor/countdowntime/countdowntime.js')?>"></script>
	<script src="<?php echo base_url('js/main.js')?>"></script>

</body>
</html>