<!DOCTYPE html>
<html lang="en">
<head>
	<title>Web based contact book</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('fonts/font-awesome-4.7.0/css/font-awesome.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('fonts/Linearicons-Free-v1.0.0/icon-font.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/animate/animate.css')?>">
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/css-hamburgers/hamburgers.min.css')?>">

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/animsition/css/animsition.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/select2/select2.min.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/daterangepicker/daterangepicker.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/util.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/main.css')?>">

</head>
<body>
<?php 

foreach($val as $fetch)
{

?>
	<div class="limiter">
		<div class="container-login100" style="background-color: #008CBA;">
			<div class="wrap-login100 p-l-110 p-r-110 p-t-62 p-b-33">
				<form class="login100-form validate-form flex-sb flex-w" action="<?php echo base_url()."index.php/Admin/Shop_Controller/update/"?>" method="post">
					<span class="login100-form-title p-b-53">
						Edit product details
					</span>

                    <input type="hidden" name="id" value="<?php echo $fetch['id']?>">
					
					<div class="p-t-31 p-b-9">
						<span class="txt1">
							Product Name
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Product name is required">
						
						<input type="text" name="prod_name"  class="input100" value="<?php echo $fetch['product_name']?>"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Unit Price
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Unit price is required">
						
						<input type="number" name="unit_price"  class="input100" value="<?php echo $fetch['unit_price']?>"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Transport Tax
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Transport tax is required">
						
						<input type="number" name="transport_tax"  class="input100" value="<?php echo $fetch['transport_tax']?>"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Sales tax
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Sales tax is required">
						
						<input type="number" name="sales_tax"  class="input100" value="<?php echo $fetch['sales_tax']?>"/>
						<span class="focus-input100"></span>
					</div>

                    <div class="p-t-31 p-b-9">
						<span class="txt1">
							Minimum selling price
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Minimum selling price is required">
						
						<input type="number" name="minimum_selling_price"  class="input100" value="<?php echo $fetch['msp']?>"/>
						<span class="focus-input100"></span>
					</div>
					
					<div class="container-login100-form-btn m-t-17">
						<input type="submit" name="submit" value="Update"  class="login100-form-btn">
					</div>

					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	<script src="<?php echo base_url('vendor/jquery/jquery-3.2.1.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/animsition/js/animsition.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/bootstrap/js/popper.js')?>"></script>
	<script src="<?php echo base_url('vendor/bootstrap/js/bootstrap.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/select2/select2.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/daterangepicker/moment.min.js')?>"></script>
	<script src="<?php echo base_url('vendor/daterangepicker/daterangepicker.js')?>"></script>
	<script src="<?php echo base_url('vendor/countdowntime/countdowntime.js')?>"></script>
	<script src="<?php echo base_url('js/main.js')?>"></script>
    <?php } ?>
</body>
</html>