<?php
class Shop_Model extends CI_model{

function insert_form($data)
{

    $this->db->insert('add_products',$data);

}

function products_view()
{
    $exe = $this->db->get('add_products');
    return $exe->result_array();

}

function Edit($id)
{
    $exe = $this->db->get_where('add_products', array('id'=>$id));
    return $exe->result_array();
}

function Update($data, $id)
{
    $this->db->update('add_products', $data, array('id'=>$id));
}

function delete($id)
{
$this->db->delete('add_products', array('id'=>$id));
}

function getData()
{
    $exe = $this->db->get('add_products');
    return $exe->result_array();

}
}
?>