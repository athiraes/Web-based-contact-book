<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Shop_Controller extends CI_Controller {

	public function __construct() {

        parent::__construct();

        $this->load->helper(array('form'));
        $this->load->library('form_validation');
        $this->load->model('Shop_Model');
  }
///////////////////Admin/////////////////////////////////
	public function index()
	{
           
      $this->load->view('index');

	}

    public function products_insertion()
    {
      
      $data['product_name'] = $this->input->post('prod_name');
      $data['unit_price'] = $this->input->post('unit_price');
      $data['transport_tax'] = $this->input->post('transport_tax');
      $data['sales_tax'] = $this->input->post('sales_tax');
      $data['msp'] = $this->input->post('minimum_selling_price');
      //print_r($data);die;

      $this->Shop_Model->insert_form($data);

       
      echo "<script>
            alert('Product Added successfully!!');
            window.location.href='http://localhost/Shop/Codeigniter/index.php/Admin/Shop_Controller/index';
            </script>";
         
    }

    public function prod_view()
    {
     $exe['val'] =  $this->Shop_Model->products_view();
     $this->load->view('product_list_view',$exe);
    }

    public function edit($id)
    {
    $exe['val'] = $this->Shop_Model->Edit($id);
    $this->load->view('edit', $exe);
    }

    public function update()
    {
      $id = $this->input->post('id');
      //echo $id;
      $data['product_name'] = $this->input->post('prod_name');
      $data['unit_price'] = $this->input->post('unit_price');
      $data['transport_tax'] = $this->input->post('transport_tax');
      $data['sales_tax'] = $this->input->post('sales_tax');
      $data['msp'] = $this->input->post('minimum_selling_price');
      //print_r($data);die;
      $this->Shop_Model->Update($data, $id);
      redirect(base_url()."index.php/Admin/Shop_Controller/prod_view/");
    }

    public function Delete($id)
      {
      $this->Shop_Model->delete($id);
      redirect(base_url()."index.php/Admin/Shop_Controller/prod_view/");
      
      }

//////////////////////User frontend//////////////////////////

public function sales_form()
{
  $exe['val'] = $this->Shop_Model->getData();
	$this->load->view('user_form', $exe);
}

public function insert_data()
{

}

}
?>